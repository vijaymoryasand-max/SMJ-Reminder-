# SMJ Reminder — APK build without Android Studio

This project includes a GitHub Actions workflow that can build the APK in the cloud. You do **not** need Android Studio on your PC.

## Easiest method
1. Create a free GitHub account at https://github.com/ if you do not already have one.
2. Create a new repository, for example `SMJReminder`.
3. Upload **all files and folders from this ZIP** to the repository, including `.github/workflows/build-apk.yml`.
4. Open the repository's **Actions** tab.
5. Select **Build SMJ Reminder APK** and press **Run workflow** (or push to `main`).
6. After the workflow finishes, open the completed workflow run.
7. Under **Artifacts**, download `SMJ-Reminder-debug-apk`.
8. Extract it and install `app-debug.apk` on the Android phone.

The workflow installs Java, Android SDK Platform 35, Build Tools 35.0.0, and Gradle 8.7 automatically in GitHub's build machine.

## Important
- This is a debug APK for testing and personal use.
- Google Calendar is not required for the basic reminder/alarm features.
- The app stores reminders locally on the phone.
