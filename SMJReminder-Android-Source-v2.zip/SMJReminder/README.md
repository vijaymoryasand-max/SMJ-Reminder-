# SMJ Reminder – Android v1

Native Android reminder app for meetings, site visits, calls, service visits and payment follow-ups.

## Features
- Exact alarm reminders with ringtone/notification
- Date and time picker
- Customer/person, phone, location and notes
- Call and WhatsApp shortcuts
- Mark complete / delete
- Offline local storage
- Reschedules future reminders after device reboot/timezone change

## Build
Open this folder in Android Studio (Hedgehog or newer) with Android SDK 35 installed, let Gradle sync, then Build > Build APK(s).

Package: `com.smjlifters.reminder`
Min SDK: 26
Target SDK: 35

Android 13+ notification permission and Android 12+ exact-alarm permission are requested at startup.
