package com.smjlifters.reminder;
public class Reminder { long id; String title,type,person,phone,location,notes; long time; boolean done; Reminder(long i,String t,String ty,String p,String ph,String l,String n,long tm){id=i;title=t;type=ty;person=p;phone=ph;location=l;notes=n;time=tm;} }
