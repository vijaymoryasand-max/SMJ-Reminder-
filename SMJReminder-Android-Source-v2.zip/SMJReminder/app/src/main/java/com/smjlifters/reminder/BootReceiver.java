package com.smjlifters.reminder;
import android.content.*;import android.app.*;import android.os.*;import java.util.*;
public class BootReceiver extends BroadcastReceiver { public void onReceive(Context c,Intent i){ for(Reminder r:ReminderStore.all(c)) if(!r.done && r.time>System.currentTimeMillis()) MainActivity.schedule(c,r); } }
